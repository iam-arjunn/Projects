sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("com.deloitte.mdg.cost.center.costcenter.controller.App", {
      onInit() {
      }
  });
});